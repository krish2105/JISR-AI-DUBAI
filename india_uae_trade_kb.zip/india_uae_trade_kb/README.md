# India–UAE Trade Knowledge Base — Official Sources

This folder is a source manifest and downloader for an India-to-UAE trade/customs knowledge base. The manifest lists official documents and official public information pages only: UAE/Dubai/Abu Dhabi government sources, India’s Department of Commerce/DGFT/ICEGATE, the UAE Federal Tax Authority, and the International Chamber of Commerce (ICC). No vendor blogs are KB sources.

## Contents

- `sources.csv` — the requested Phase 5 source register: title, issuing body, official URL, document date, local filename, download mode, and notes.
- `download_official_sources.py` — downloads binary documents to `downloads/` and official page snapshots to `references/`; writes a `download_status.csv` report.
- `downloads/` — downloaded PDFs/XLSX files (created by the downloader).
- `references/` — HTML snapshots of official legislation, portal indexes, and ICC pages (created by the downloader).

## Download the source set

Run this from this directory on a machine with outbound internet access:

```bash
python3 download_official_sources.py
```

The script tries every manifest row and continues when one source fails. See `download_status.csv` for HTTP status, content type, byte count, and any error. Some official ICC free-document pages use an ICC download/checkout flow rather than exposing a static PDF URL; those entries are saved as the official landing-page snapshot, and the original PDF may need to be downloaded manually from ICC’s own page.

**Execution-environment limitation:** outbound DNS/network access was unavailable while preparing this package in ChatGPT, so the original PDF/XLSX binaries are not pre-populated here. The manifest, official links, and downloader are included so the originals can be fetched in your network-connected project environment. No empty or fabricated documents have been substituted for source files.

## Source-selection notes

1. **UAE/GCC tariff:** use Dubai Customs’ current live 12-digit HS master and transition guide together with UAE Cabinet Resolution No. 119 of 2024. The live master can change without a stable publication date; re-check its version before classifying a product or filing an entry.
2. **India–UAE CEPA:** the complete agreement PDF is the controlling source for Chapter 3 (Rules of Origin) and the product-specific rules annex. The Government of India’s CEPA FAQ is included only as a secondary official aid, not a substitute for treaty text.
3. **Certificates of Origin:** DGFT Trade Notice No. 05/2022–2023 is the CEPA-specific notice listed here for electronic filing/issuance of preferential CoOs. DGFT Trade Notice No. 04/2022–2023 is commonly confused with it; it concerns extension/mandatory electronic filing for **non-preferential** CoOs, so it is not labelled as the CEPA-specific notice. The live DGFT CoO relevant-documents index is included for subsequent notices.
4. **Dubai import procedures:** use the 2025 Version 09 Dubai Customs Services Guide and live declaration-service page for document requirements. The particular permit, origin evidence and declaration requirements depend on the goods, trade arrangement, and customs procedure.
5. **Indian export filing:** DGFT’s export guide and ICEGATE manuals are procedural aids. Re-check live DGFT notifications, ICEGATE workflows, customs rules and any product-specific export restrictions before filing.
6. **Incoterms® 2020:** ICC’s public overview and ICC-hosted free-document pages are used. Incoterms allocate delivery obligations, costs and risks; they do not replace the sales contract, tariff classification, origin rules, customs requirements or tax advice.
7. **UAE import VAT:** the listed VAT Import Declaration User Guide is dated September 2018. It is kept because it is an official importer guide, but it is old; consult the current FTA VAT guides index and current law for operational decisions.

## Use and maintenance

- Treat the documents as a research/knowledge-base corpus, not as legal or customs advice. Verify the current edition and the tariff/permit rules for each SKU and transaction.
- Store official originals unchanged and keep the `sources.csv` metadata with the KB. For traceability, retain download dates and `download_status.csv` after fetching.
- This project folder is configured so only `README.md` is intended to be committed; local source files, metadata and scripts remain ignored, per the stated repository convention. If `sources.csv` must be committed for Phase 5 review, adjust `.gitignore` deliberately rather than assuming it is tracked.
