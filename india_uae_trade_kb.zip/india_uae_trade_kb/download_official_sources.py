#!/usr/bin/env python3
"""Download official India–UAE trade KB sources listed in sources.csv.

Run from this folder with Python 3 on a network-connected machine:
    python3 download_official_sources.py

Only the official URLs in sources.csv are fetched. Failures are recorded and do
not stop later downloads. HTML rows are saved as source-page snapshots; file rows
are saved as originals. This script does not scrape or download vendor blogs.
"""
from __future__ import annotations

import csv
import mimetypes
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "sources.csv"
STATUS = ROOT / "download_status.csv"
USER_AGENT = "IndiaUAETradeKnowledgeBase/1.0 (official-source downloader)"
TIMEOUT_SECONDS = 35
MAX_ATTEMPTS = 2


def fetch(url: str):
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "*/*"})
    with urlopen(req, timeout=TIMEOUT_SECONDS) as response:
        data = response.read()
        return data, getattr(response, "status", 200), response.headers.get("Content-Type", "")


def main() -> int:
    if not MANIFEST.exists():
        print(f"Missing manifest: {MANIFEST}", file=sys.stderr)
        return 2

    with MANIFEST.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))

    results = []
    success = 0
    for number, row in enumerate(rows, start=1):
        rel_name = row.get("local_filename", "").strip()
        url = row.get("url", "").strip()
        mode = row.get("download_mode", "").strip().lower()
        result = {
            "local_filename": rel_name,
            "status": "FAILED",
            "http_status": "",
            "content_type": "",
            "bytes": 0,
            "error": "",
        }
        try:
            if not rel_name or not url or mode not in {"file", "page"}:
                raise ValueError("Manifest row is missing local_filename/url or has an invalid download_mode")
            target = (ROOT / rel_name).resolve()
            if ROOT.resolve() not in target.parents:
                raise ValueError("Output path escapes the knowledge-base folder")
            target.parent.mkdir(parents=True, exist_ok=True)

            last_error = None
            for attempt in range(1, MAX_ATTEMPTS + 1):
                try:
                    data, status_code, content_type = fetch(url)
                    break
                except (HTTPError, URLError, TimeoutError, OSError) as exc:
                    last_error = exc
                    if attempt < MAX_ATTEMPTS:
                        time.sleep(1.5)
            else:
                raise last_error or RuntimeError("Unknown download failure")

            content_type_l = content_type.lower()
            looks_html = "text/html" in content_type_l or data.lstrip()[:30].lower().startswith((b"<!doctype html", b"<html"))
            if mode == "file" and looks_html:
                raise ValueError(f"Expected a document binary but server returned HTML ({content_type or 'unknown content type'}); check official URL/manual download flow")
            if mode == "page" and not looks_html and "application/xhtml" not in content_type_l:
                # Preserve bytes rather than silently mislabeling a non-HTML response.
                raise ValueError(f"Expected an HTML source page but server returned {content_type or 'unknown content type'}")
            target.write_bytes(data)
            result.update({
                "status": "DOWNLOADED",
                "http_status": status_code,
                "content_type": content_type,
                "bytes": len(data),
            })
            success += 1
            print(f"[{number:02d}/{len(rows):02d}] OK   {rel_name} ({len(data):,} bytes)")
        except Exception as exc:  # collect failures so remaining sources are attempted
            result["error"] = f"{type(exc).__name__}: {exc}"
            print(f"[{number:02d}/{len(rows):02d}] FAIL {rel_name or '(unnamed row)'} — {result['error']}")
        results.append(result)

    with STATUS.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["local_filename", "status", "http_status", "content_type", "bytes", "error"])
        writer.writeheader()
        writer.writerows(results)

    failed = len(results) - success
    print(f"\nFinished: {success} downloaded, {failed} failed. Status log: {STATUS}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
